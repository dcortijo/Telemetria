#pragma once

#include <string>

namespace machineid {
	std::string machineHash();
}
